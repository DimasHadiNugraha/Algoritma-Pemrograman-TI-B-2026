
def penambahan(a,b):
    return (a + b)

def pegurangan(a, b):
    return (a - b)

def perkalian(a, b):
    return (a*b)

def modulus(a,b):
    return (a % b)
    


