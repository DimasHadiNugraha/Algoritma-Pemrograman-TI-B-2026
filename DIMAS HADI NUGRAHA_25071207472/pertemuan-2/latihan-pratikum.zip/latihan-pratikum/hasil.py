import mymath

a = mymath.penambahan(5, 4)
print(a)

b = mymath.pegurangan(5, 6)
print(b)

c = mymath.perkalian(5, 2)
print(c)

d = mymath.modulus(5, 2)
print(d)



