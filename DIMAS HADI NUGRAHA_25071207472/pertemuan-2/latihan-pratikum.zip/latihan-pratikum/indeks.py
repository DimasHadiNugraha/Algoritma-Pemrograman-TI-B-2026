import myModul as md

md.greeting('dimas')

a = md.person1["age"]
b = md.person1["name"]
print(a)
print(b)


